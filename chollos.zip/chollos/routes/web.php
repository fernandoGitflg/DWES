<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CholloController;
use App\Http\Controllers\CategoriaController;

/**
 * Archivo de rutas web
 * ---------------------
 * Define las rutas principales de la aplicación:
 * - Listado de chollos
 * - CRUD de chollos
 * - Gestión de categorías
 * 
 * Desarrollado por: Fernando
 */

// Página principal → listado de chollos
Route::get('/', [CholloController::class, 'index'])->name('chollos.index');

// Detalle de un chollo
Route::get('/chollos/{id}', [CholloController::class, 'show'])->name('chollos.show');

// Crear chollo
Route::get('/crear', [CholloController::class, 'create'])->name('chollos.create');
Route::post('/crear', [CholloController::class, 'store'])->name('chollos.store');

// Editar chollo
Route::get('/editar/{id}', [CholloController::class, 'edit'])->name('chollos.edit');
Route::put('/editar/{id}', [CholloController::class, 'update'])->name('chollos.update');

// Borrar chollo
Route::delete('/borrar/{id}', [CholloController::class, 'destroy'])->name('chollos.destroy');

// Chollos filtrados por categoría
Route::get('/categoria/{id}', [CholloController::class, 'porCategoria'])->name('chollos.categoria');

// Listado de categorías
Route::get('/categorias', [CategoriaController::class, 'index'])->name('categorias.index');

// Crear categoría
Route::post('/categorias', [CategoriaController::class, 'store'])->name('categorias.store');

// Borrar categoría
Route::delete('/categorias/{id}', [CategoriaController::class, 'destroy'])->name('categorias.destroy');
