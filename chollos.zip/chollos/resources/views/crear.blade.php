{{-- 
    Vista: crear.blade.php
    -----------------------
    Formulario para crear un nuevo chollo.
    Desarrollado por: Fernando
--}}

<div style="max-width: 1000px; margin: 0 auto;">

    {{-- HEADER alineado igual que en index --}}
    <header style="display: flex; align-items: center; gap: 20px; margin-bottom: 20px;">
        <img src="{{ asset('logo.jpg') }}" alt="Logo Chollos" width="80">

        <nav style="display: flex; gap: 15px; margin-left: auto;">
            <a href="{{ route('chollos.index') }}">Inicio</a>
            <a href="{{ route('chollos.index', ['orden' => 'nuevos']) }}">Nuevos</a>
            <a href="{{ route('chollos.index', ['orden' => 'destacados']) }}">Destacados</a>
        </nav>
    </header>

    {{-- TÍTULO alineado con el listado --}}
    <h1 style="margin-bottom: 20px;">Crear un nuevo Chollo</h1>

    {{-- Mensajes --}}
    @if (session('success'))
        <p style="color: green;">{{ session('success') }}</p>
    @endif

    @if (session('error'))
        <p style="color: red;">{{ session('error') }}</p>
    @endif

    @if ($errors->any())
        <div style="color: red;">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    {{-- FORMULARIO alineado dentro del mismo ancho --}}
    <form action="{{ route('chollos.store') }}" method="POST" enctype="multipart/form-data"
        style="display: flex; flex-direction: column; gap: 12px;">
        @csrf

        <div style="display: flex; flex-direction: column; gap: 4px;">
            <label>Título:</label>
            <input type="text" name="titulo" value="{{ old('titulo') }}" style="padding: 6px;">
        </div>

        <div style="display: flex; flex-direction: column; gap: 4px;">
            <label>Descripción:</label>
            <textarea name="descripcion" style="padding: 6px;">{{ old('descripcion') }}</textarea>
        </div>

        <div style="display: flex; flex-direction: column; gap: 4px;">
            <label>URL del chollo:</label>
            <input type="text" name="url" value="{{ old('url') }}" style="padding: 6px;">
        </div>

        <div style="display: flex; flex-direction: column; gap: 4px;">
            <label>Categoría:</label>
            <select name="categoria_id" style="padding: 6px;">
                <option value="">-- Selecciona una categoría --</option>
                @foreach ($categorias as $categoria)
                    <option value="{{ $categoria->id }}"
                        {{ old('categoria_id') == $categoria->id ? 'selected' : '' }}>
                        {{ $categoria->name }}
                    </option>
                @endforeach
            </select>
        </div>

        <div style="display: flex; flex-direction: column; gap: 4px;">
            <label>Puntuación (0-10):</label>
            <input type="number" name="puntuacion" min="0" max="10" value="{{ old('puntuacion') }}"
                style="padding: 6px;">
        </div>

        <div style="display: flex; flex-direction: column; gap: 4px;">
            <label>Precio original:</label>
            <input type="number" step="0.01" name="precio" value="{{ old('precio') }}" style="padding: 6px;">
        </div>

        <div style="display: flex; flex-direction: column; gap: 4px;">
            <label>Precio con descuento:</label>
            <input type="number" step="0.01" name="precio_descuento" value="{{ old('precio_descuento') }}"
                style="padding: 6px;">
        </div>

        <div style="display: flex; align-items: center; gap: 6px;">
            <label>Disponible:</label>
            <input type="checkbox" name="disponible" checked>
        </div>

        <div style="display: flex; flex-direction: column; gap: 4px;">
            <label>Imagen del chollo:</label>
            <input type="file" name="imagen">
        </div>

        <button type="submit" style="padding: 8px 14px; font-size: 16px; font-weight: bold; align-self: flex-end;">
            Crear chollo
        </button>

    </form>


    <p style="margin-top: 20px;">
        <a href="{{ route('chollos.index') }}">Volver al listado</a>
    </p>

    <footer style="text-align: right; margin-top: 40px; padding: 10px; color: #555;">
        © {{ date('Y') }} Fernando – Chollos App
    </footer>

</div>
