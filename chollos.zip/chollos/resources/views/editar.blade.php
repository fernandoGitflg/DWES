{{-- 
    Vista: editar.blade.php
    ------------------------
    Formulario para editar un chollo existente.
    Carga los datos actuales y permite modificarlos.
    Desarrollado por: Fernando
--}}
<header style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">

    <div style="display: flex; align-items: center; gap: 20px;">
        <img src="{{ asset('logo.jpg') }}" alt="Logo Chollos" width="80">

        <nav style="display: flex; gap: 15px;">
            <a href="{{ route('chollos.index') }}">Inicio</a>
            <a href="{{ route('chollos.index', ['orden' => 'nuevos']) }}">Nuevos</a>
            <a href="{{ route('chollos.index', ['orden' => 'destacados']) }}">Destacados</a>
        </nav>
    </div>

</header>
<h1>Editar Chollo</h1>

{{-- Mensajes de éxito o error --}}
@if(session('success'))
    <p style="color: green;">{{ session('success') }}</p>
@endif

@if(session('error'))
    <p style="color: red;">{{ session('error') }}</p>
@endif

{{-- Mostrar errores de validación --}}
@if ($errors->any())
    <div style="color: red;">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

{{-- Formulario de edición --}}
<form action="{{ route('chollos.update', $chollo->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT')

    <p>
        <label>Título:</label><br>
        <input type="text" name="titulo" value="{{ old('titulo', $chollo->titulo) }}">
    </p>

    <p>
        <label>Descripción:</label><br>
        <textarea name="descripcion">{{ old('descripcion', $chollo->descripcion) }}</textarea>
    </p>

    <p>
        <label>URL del chollo:</label><br>
        <input type="text" name="url" value="{{ old('url', $chollo->url) }}">
    </p>

    <p>
        <label>Categoría:</label><br>
        <select name="categoria_id">
            @foreach ($categorias as $categoria)
                <option value="{{ $categoria->id }}"
                    {{ old('categoria_id', $chollo->categoria_id) == $categoria->id ? 'selected' : '' }}>
                    {{ $categoria->name }}
                </option>
            @endforeach
        </select>
    </p>

    <p>
        <label>Puntuación (0-10):</label><br>
        <input type="number" name="puntuacion" min="0" max="10" 
               value="{{ old('puntuacion', $chollo->puntuacion) }}">
    </p>

    <p>
        <label>Precio original:</label><br>
        <input type="number" step="0.01" name="precio" 
               value="{{ old('precio', $chollo->precio) }}">
    </p>

    <p>
        <label>Precio con descuento:</label><br>
        <input type="number" step="0.01" name="precio_descuento" 
               value="{{ old('precio_descuento', $chollo->precio_descuento) }}">
    </p>

    <p>
        <label>Disponible:</label>
        <input type="checkbox" name="disponible" 
               {{ old('disponible', $chollo->disponible) ? 'checked' : '' }}>
    </p>

    {{-- Imagen actual --}}
    @if($chollo->imagen)
        <p>
            <strong>Imagen actual:</strong><br>
            <img src="{{ asset('storage/' . $chollo->imagen) }}" width="150">
        </p>
    @endif

    <p>
        <label>Subir nueva imagen (opcional):</label><br>
        <input type="file" name="imagen">
    </p>

    <p>
        <button type="submit">Actualizar chollo</button>
    </p>
</form>

{{-- Enlace para volver --}}
<p>
    <a href="{{ route('chollos.index') }}">Volver al listado</a>
</p>
<footer style="text-align: right; margin-top: 40px; padding: 10px; color: #555;">
    © {{ date('Y') }} Fernando – Chollos App
</footer>