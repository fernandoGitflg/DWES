{{-- 
    Vista: index.blade.php
    -----------------------
    Muestra el listado principal de chollos.
    Desarrollado por: Fernando
--}}

{{-- CONTENEDOR GLOBAL --}}
<div style="max-width: 1000px; margin: 0 auto;">

    {{-- HEADER alineado con los chollos --}}
    <header style="display: flex; align-items: center; gap: 20px; margin-bottom: 20px;">
        <img src="{{ asset('logo.jpg') }}" alt="Logo Chollos" width="80">
        <h1 style="margin: 0;">Chollos</h1>

        <nav style="display: flex; gap: 15px; margin-left: auto;">
            <a href="{{ route('chollos.index') }}">Inicio</a>
            <a href="{{ route('chollos.index', ['orden' => 'nuevos']) }}">Nuevos</a>
            <a href="{{ route('chollos.index', ['orden' => 'destacados']) }}">Destacados</a>
        </nav>
    </header>

    {{-- TÍTULO LISTA + FILTRO + BOTÓN, alineados a los bordes de los chollos --}}
    <div style="display: flex; align-items: center; margin-bottom: 20px;">

        <form action="{{ route('chollos.index') }}" method="GET" style="flex-grow: 1; margin-right: 20px;">
            <input type="hidden" name="categoria" value="{{ request('categoria') }}">
            <input type="text" name="buscar" placeholder="Buscar chollos..." value="{{ request('buscar') }}"
                style="width: 100%; padding: 8px; font-size: 16px;">
        </form>

        <div style="display: flex; align-items: center; gap: 15px;">

            <form action="{{ route('chollos.index') }}" method="GET"
                style="display: flex; align-items: center; gap: 10px;">
                <select name="categoria" style="height: 36px; padding: 5px; font-size: 16px;"
                    onchange="this.form.submit()">
                    <option value="">-- Categorías --</option>

                    @foreach ($categorias as $categoria)
                        <option value="{{ $categoria->id }}"
                            {{ request('categoria') == $categoria->id ? 'selected' : '' }}>
                            {{ $categoria->name }}
                        </option>
                    @endforeach
                </select>
                <button type="submit" style="display:none;"></button>
            </form>

            <form action="{{ route('chollos.create') }}" method="GET">
                <button type="submit" style="font-size: 16px; height: 36px;">
                    Crear nuevo chollo
                </button>
            </form>

        </div>

    </div>

    {{-- Mensajes de éxito o error --}}
    @if (session('success'))
        <p style="color: green;">{{ session('success') }}</p>
    @endif

    @if (session('error'))
        <p style="color: red;">{{ session('error') }}</p>
    @endif

    {{-- Listado de chollos --}}
    <div style="display: flex; flex-wrap: wrap; gap: 20px; justify-content: space-between;">
        @foreach ($chollos as $chollo)
            <div style="border: 1px solid #000; padding: 10px; width: 48%; box-sizing: border-box;">

                <h2>{{ $chollo->titulo }}</h2>

                @if ($chollo->imagen)
                    <img src="{{ asset('storage/' . $chollo->imagen) }}" style="max-width: 120px; height: auto;">
                @endif

                <p><strong>Categoría:</strong> {{ $chollo->categoria->name }}</p>
                <p><strong>Puntuación:</strong> {{ $chollo->puntuacion }}</p>
                <p><strong>Precio:</strong> {{ $chollo->precio }} €</p>
                <p><strong>Precio descuento:</strong> {{ $chollo->precio_descuento }} €</p>

                <p><a href="{{ route('chollos.show', $chollo->id) }}">Ver detalle</a></p>
                <p><a href="{{ route('chollos.edit', $chollo->id) }}">Editar</a></p>

                <form action="{{ route('chollos.destroy', $chollo->id) }}" method="POST">
                    @csrf
                    @method('DELETE')
                    <button type="submit">Borrar</button>
                </form>

            </div>
        @endforeach
    </div>

    {{ $chollos->links('vendor.pagination.simple-default') }}

    <div style= "color: #555;text-align: right;">
        © {{ date('Y') }} Fernando – Chollos App
    </div>
</div>
