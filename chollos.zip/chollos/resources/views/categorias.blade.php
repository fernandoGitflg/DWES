{{-- 
    Vista: categorias.blade.php
    ----------------------------
    Muestra el listado de categorías y permite crear y eliminar.
    Desarrollado por: Fernando
--}}
<header>
    <img src="{{ asset('logo.jpg') }}" alt="Logo Chollos" width="80">
    <h1>Chollos</h1>
    <nav>
        <a href="{{ route('chollos.index') }}">Inicio</a> |
        <a href="{{ route('chollos.index', ['orden' => 'nuevos']) }}">Nuevos</a> |
        <a href="{{ route('chollos.index', ['orden' => 'destacados']) }}">Destacados</a>
    </nav>
</header>

<h1>Gestión de Categorías</h1>

{{-- Mensajes de éxito o error --}}
@if(session('success'))
    <p style="color: green;">{{ session('success') }}</p>
@endif

@if(session('error'))
    <p style="color: red;">{{ session('error') }}</p>
@endif

{{-- Mostrar errores de validación --}}
@if ($errors->any())
    <div style="color: red;">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

{{-- Formulario para crear categoría --}}
<h2>Crear nueva categoría</h2>

<form action="{{ route('categorias.store') }}" method="POST">
    @csrf

    <p>
        <label>Nombre de la categoría:</label><br>
        <input type="text" name="name" value="{{ old('name') }}">
    </p>

    <p>
        <button type="submit">Crear categoría</button>
    </p>
</form>

<hr>

{{-- Listado de categorías --}}
<h2>Listado de categorías</h2>

@foreach ($categorias as $categoria)
    <div style="border: 1px solid #000; padding: 10px; margin-bottom: 10px;">

        <p><strong>Nombre:</strong> {{ $categoria->name }}</p>
        <p><strong>Chollos asociados:</strong> {{ $categoria->chollos_count }}</p>

        {{-- Formulario para borrar --}}
        <form action="{{ route('categorias.destroy', $categoria->id) }}" method="POST">
            @csrf
            @method('DELETE')
            <button type="submit">Eliminar</button>
        </form>

    </div>
@endforeach

{{-- Enlace para volver --}}
<p>
    <a href="{{ route('chollos.index') }}">Volver al listado de chollos</a>
</p>
<footer style="text-align: right; margin-top: 40px; padding: 10px; color: #555;">
    © {{ date('Y') }} Fernando – Chollos App
</footer>
