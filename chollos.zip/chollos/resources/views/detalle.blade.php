{{-- 
    Vista: detalle.blade.php
    ------------------------
    Muestra la información completa de un chollo.
    Desarrollado por: Fernando
--}}
<header style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">

    <div style="display: flex; align-items: center; gap: 20px;">
        <img src="{{ asset('logo.jpg') }}" alt="Logo Chollos" width="80">

        <nav style="display: flex; gap: 15px;">
            <a href="{{ route('chollos.index') }}">Inicio</a>
            <a href="{{ route('chollos.index', ['orden' => 'nuevos']) }}">Nuevos</a>
            <a href="{{ route('chollos.index', ['orden' => 'destacados']) }}">Destacados</a>
        </nav>
    </div>

</header>

<h1>Detalle del Chollo</h1>

{{-- Mensajes de éxito o error --}}
@if(session('success'))
    <p style="color: green;">{{ session('success') }}</p>
@endif

@if(session('error'))
    <p style="color: red;">{{ session('error') }}</p>
@endif

{{-- Título --}}
<h2>{{ $chollo->titulo }}</h2>

{{-- Imagen si existe --}}
@if($chollo->imagen)
    <img src="{{ asset('storage/' . $chollo->imagen) }}" width="200">
@endif

<p><strong>Categoría:</strong> {{ $chollo->categoria->name }}</p>

<p><strong>Descripción:</strong></p>
<p>{{ $chollo->descripcion }}</p>

<p><strong>Puntuación:</strong> {{ $chollo->puntuacion }}</p>

<p><strong>Precio original:</strong> {{ $chollo->precio }} €</p>

<p><strong>Precio con descuento:</strong> {{ $chollo->precio_descuento }} €</p>

<p>
    <strong>Enlace al chollo:</strong>
    <a href="{{ $chollo->url }}" target="_blank">Visitar oferta</a>
</p>

{{-- Botón para volver --}}
<p>
    <a href="{{ route('chollos.index') }}">Volver al listado</a>
</p>
<footer style="text-align: right; margin-top: 40px; padding: 10px; color: #555;">
    © {{ date('Y') }} Fernando – Chollos App
</footer>