<?php

/**
 * Controlador CategoriaController
 * -------------------------------
 * Gestiona las operaciones CRUD de las categorías.
 * Incluye validación, manejo de errores y vistas asociadas.
 * 
 * Desarrollado por: Fernando
 */

namespace App\Http\Controllers;

use App\Models\Categoria;
use Illuminate\Http\Request;

class CategoriaController extends Controller
{
    /**
     * Mostrar listado de categorías.
     */
    public function index()
    {
        $categorias = Categoria::withCount('chollos')->get();
        return view('categorias', compact('categorias'));
    }

    /**
     * Guardar una nueva categoría.
     */
    public function store(Request $request)
    {
        // Validación
        $request->validate([
            'name' => 'required|unique:categorias,name|max:255'
        ]);

        try {
            Categoria::create([
                'name' => $request->name
            ]);

            return redirect()->back()->with('success', 'Categoría creada correctamente');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Error al crear la categoría');
        }
    }

    /**
     * Eliminar una categoría.
     */
    public function destroy($id)
    {
        try {
            Categoria::findOrFail($id)->delete();
            return redirect()->back()->with('success', 'Categoría eliminada');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'No se pudo eliminar la categoría');
        }
    }
}
