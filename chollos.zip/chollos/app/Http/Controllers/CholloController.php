<?php

/**
 * Controlador CholloController
 * ----------------------------
 * Gestiona los chollos: listar, crear, editar, borrar y mostrar detalles.
 * Incluye validación, subida de imágenes y manejo de errores.
 * 
 * Desarrollado por: Fernando
 */

namespace App\Http\Controllers;

use App\Models\Chollo;
use App\Models\Categoria;
use Illuminate\Http\Request;

class CholloController extends Controller
{
    /**
     * Listado principal de chollos.
     */
    public function index(Request $request)
    {
        $orden = $request->get('orden');
        $categoria = $request->get('categoria');

        if ($categoria === 'agregar') {
            return redirect()->route('categorias.index');
        }

        $query = Chollo::with('categoria');

        // FILTRO POR CATEGORÍA
        if ($categoria) {
            $query->where('categoria_id', $categoria);
        }

        // FILTRO POR BUSCADOR
        if ($request->filled('buscar')) {
            $query->where(function ($q) use ($request) {
                $q->where('titulo', 'like', '%' . $request->buscar . '%')
                    ->orWhere('descripcion', 'like', '%' . $request->buscar . '%');
            });
        }

        // ORDEN
        if ($orden === 'nuevos') {
            $query->orderBy('created_at', 'desc');
        } elseif ($orden === 'destacados') {
            $query->orderBy('puntuacion', 'desc');
        }

        $chollos = $query->paginate(6);

        // Mantener filtros en la paginación
        $chollos->appends([
            'orden' => $orden,
            'categoria' => $categoria,
            'buscar' => $request->buscar
        ]);

        $categorias = Categoria::all();

        return view('index', compact('chollos', 'categorias'));
    }


    /**
     * Mostrar formulario de creación.
     */
    public function create()
    {
        $categorias = Categoria::all();
        return view('crear', compact('categorias'));
    }

    /**
     * Guardar un nuevo chollo.
     */
    public function store(Request $request)
    {
        // Validación
        $request->validate([
            'titulo' => 'required|max:255',
            'descripcion' => 'required',
            'url' => 'required|url',
            'categoria_id' => 'required|exists:categorias,id',
            'puntuacion' => 'required|integer|min:0|max:10',
            'precio' => 'required|numeric|min:0',
            'precio_descuento' => 'required|numeric|min:0',
            'imagen' => 'nullable|image|max:2048'
        ]);

        try {
            // Subida de imagen
            $rutaImagen = null;
            if ($request->hasFile('imagen')) {
                $rutaImagen = $request->file('imagen')->store('imagenes', 'public');
            }

            Chollo::create([
                'titulo' => $request->titulo,
                'descripcion' => $request->descripcion,
                'url' => $request->url,
                'categoria_id' => $request->categoria_id,
                'puntuacion' => $request->puntuacion,
                'precio' => $request->precio,
                'precio_descuento' => $request->precio_descuento,
                'disponible' => $request->disponible ? 1 : 0,
                'imagen' => $rutaImagen
            ]);

            return redirect()->route('chollos.index')->with('success', 'Chollo creado correctamente');

        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Error al crear el chollo');
        }
    }

    /**
     * Mostrar detalle de un chollo.
     */
    public function show($id)
    {
        $chollo = Chollo::findOrFail($id);
        return view('detalle', compact('chollo'));
    }

    /**
     * Mostrar formulario de edición.
     */
    public function edit($id)
    {
        $chollo = Chollo::findOrFail($id);
        $categorias = Categoria::all();
        return view('editar', compact('chollo', 'categorias'));
    }

    /**
     * Actualizar un chollo.
     */
    public function update(Request $request, $id)
    {
        $chollo = Chollo::findOrFail($id);

        // Validación
        $request->validate([
            'titulo' => 'required|max:255',
            'descripcion' => 'required',
            'url' => 'required|url',
            'categoria_id' => 'required|exists:categorias,id',
            'puntuacion' => 'required|integer|min:0|max:10',
            'precio' => 'required|numeric|min:0',
            'precio_descuento' => 'required|numeric|min:0',
            'imagen' => 'nullable|image|max:2048'
        ]);

        try {
            // Subida de imagen nueva
            if ($request->hasFile('imagen')) {
                $rutaImagen = $request->file('imagen')->store('imagenes', 'public');
                $chollo->imagen = $rutaImagen;
            }

            $chollo->update($request->except('imagen'));

            return redirect()->route('chollos.index')->with('success', 'Chollo actualizado correctamente');

        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Error al actualizar el chollo');
        }
    }

    /**
     * Eliminar un chollo.
     */
    public function destroy($id)
    {
        try {
            Chollo::findOrFail($id)->delete();
            return redirect()->route('chollos.index')->with('success', 'Chollo eliminado');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'No se pudo eliminar el chollo');
        }
    }

    public function porCategoria($id)
    {
        $chollos = Chollo::where('categoria_id', $id)
            ->with('categoria')
            ->paginate(6);

        // Mantener el filtro en la paginación
        $chollos->appends(['categoria' => $id]);

        return view('index', compact('chollos'));
    }
}
