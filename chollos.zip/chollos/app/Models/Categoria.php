<?php

/**
 * Modelo Categoria
 * ----------------
 * Representa una categoría dentro del sistema de chollos.
 * Cada categoría puede tener muchos chollos asociados.
 * 
 * Desarrollado por: Fernando
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Categoria extends Model
{
    use HasFactory;

    // Campos que se pueden rellenar masivamente
    protected $fillable = ['name'];

    /**
     * Relación 1:N
     * Una categoría tiene muchos chollos.
     */
    public function chollos()
    {
        return $this->hasMany(Chollo::class);
    }
}
