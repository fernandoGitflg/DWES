<?php

/**
 * Modelo Chollo
 * -------------
 * Representa un chollo dentro del sistema.
 * Cada chollo pertenece a una categoría.
 * 
 * Desarrollado por: Fernando
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Chollo extends Model
{
    use HasFactory;

    // Campos que se pueden rellenar masivamente
    protected $fillable = [
        'titulo',
        'descripcion',
        'url',
        'categoria_id',
        'puntuacion',
        'precio',
        'precio_descuento',
        'disponible',
        'imagen'
    ];

    /**
     * Relación N:1
     * Un chollo pertenece a una categoría.
     */
    public function categoria()
    {
        return $this->belongsTo(Categoria::class);
    }
}
