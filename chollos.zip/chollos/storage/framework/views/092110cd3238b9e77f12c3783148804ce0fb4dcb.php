
<header style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">

    <div style="display: flex; align-items: center; gap: 20px;">
        <img src="<?php echo e(asset('logo.jpg')); ?>" alt="Logo Chollos" width="80">

        <nav style="display: flex; gap: 15px;">
            <a href="<?php echo e(route('chollos.index')); ?>">Inicio</a>
            <a href="<?php echo e(route('chollos.index', ['orden' => 'nuevos'])); ?>">Nuevos</a>
            <a href="<?php echo e(route('chollos.index', ['orden' => 'destacados'])); ?>">Destacados</a>
        </nav>
    </div>

</header>
<h1>Editar Chollo</h1>


<?php if(session('success')): ?>
    <p style="color: green;"><?php echo e(session('success')); ?></p>
<?php endif; ?>

<?php if(session('error')): ?>
    <p style="color: red;"><?php echo e(session('error')); ?></p>
<?php endif; ?>


<?php if($errors->any()): ?>
    <div style="color: red;">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<form action="<?php echo e(route('chollos.update', $chollo->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <p>
        <label>Título:</label><br>
        <input type="text" name="titulo" value="<?php echo e(old('titulo', $chollo->titulo)); ?>">
    </p>

    <p>
        <label>Descripción:</label><br>
        <textarea name="descripcion"><?php echo e(old('descripcion', $chollo->descripcion)); ?></textarea>
    </p>

    <p>
        <label>URL del chollo:</label><br>
        <input type="text" name="url" value="<?php echo e(old('url', $chollo->url)); ?>">
    </p>

    <p>
        <label>Categoría:</label><br>
        <select name="categoria_id">
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($categoria->id); ?>"
                    <?php echo e(old('categoria_id', $chollo->categoria_id) == $categoria->id ? 'selected' : ''); ?>>
                    <?php echo e($categoria->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </p>

    <p>
        <label>Puntuación (0-10):</label><br>
        <input type="number" name="puntuacion" min="0" max="10" 
               value="<?php echo e(old('puntuacion', $chollo->puntuacion)); ?>">
    </p>

    <p>
        <label>Precio original:</label><br>
        <input type="number" step="0.01" name="precio" 
               value="<?php echo e(old('precio', $chollo->precio)); ?>">
    </p>

    <p>
        <label>Precio con descuento:</label><br>
        <input type="number" step="0.01" name="precio_descuento" 
               value="<?php echo e(old('precio_descuento', $chollo->precio_descuento)); ?>">
    </p>

    <p>
        <label>Disponible:</label>
        <input type="checkbox" name="disponible" 
               <?php echo e(old('disponible', $chollo->disponible) ? 'checked' : ''); ?>>
    </p>

    
    <?php if($chollo->imagen): ?>
        <p>
            <strong>Imagen actual:</strong><br>
            <img src="<?php echo e(asset('storage/' . $chollo->imagen)); ?>" width="150">
        </p>
    <?php endif; ?>

    <p>
        <label>Subir nueva imagen (opcional):</label><br>
        <input type="file" name="imagen">
    </p>

    <p>
        <button type="submit">Actualizar chollo</button>
    </p>
</form>


<p>
    <a href="<?php echo e(route('chollos.index')); ?>">Volver al listado</a>
</p>
<footer style="text-align: right; margin-top: 40px; padding: 10px; color: #555;">
    © <?php echo e(date('Y')); ?> Fernando – Chollos App
</footer><?php /**PATH C:\Users\DWES\chollos\resources\views/editar.blade.php ENDPATH**/ ?>