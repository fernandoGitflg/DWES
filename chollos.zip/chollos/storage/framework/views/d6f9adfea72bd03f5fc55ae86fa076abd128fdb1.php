<?php if($paginator->hasPages()): ?>
    <nav style="text-align:center; margin-top:20px;">
        
        <?php if($paginator->onFirstPage()): ?>
            <span style="margin:0 10px; color:#aaa;">&laquo; Anterior</span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" style="margin:0 10px;">&laquo; Anterior</a>
        <?php endif; ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" style="margin:0 10px;">Siguiente &raquo;</a>
        <?php else: ?>
            <span style="margin:0 10px; color:#aaa;">Siguiente &raquo;</span>
        <?php endif; ?>
    </nav>
<?php endif; ?>
<?php /**PATH C:\Users\DWES\chollos\resources\views/vendor/pagination/simple-default.blade.php ENDPATH**/ ?>