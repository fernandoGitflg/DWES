

<div style="max-width: 1000px; margin: 0 auto;">

    
    <header style="display: flex; align-items: center; gap: 20px; margin-bottom: 20px;">
        <img src="<?php echo e(asset('logo.jpg')); ?>" alt="Logo Chollos" width="80">

        <nav style="display: flex; gap: 15px; margin-left: auto;">
            <a href="<?php echo e(route('chollos.index')); ?>">Inicio</a>
            <a href="<?php echo e(route('chollos.index', ['orden' => 'nuevos'])); ?>">Nuevos</a>
            <a href="<?php echo e(route('chollos.index', ['orden' => 'destacados'])); ?>">Destacados</a>
        </nav>
    </header>

    
    <h1 style="margin-bottom: 20px;">Crear un nuevo Chollo</h1>

    
    <?php if(session('success')): ?>
        <p style="color: green;"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <p style="color: red;"><?php echo e(session('error')); ?></p>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div style="color: red;">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    
    <form action="<?php echo e(route('chollos.store')); ?>" method="POST" enctype="multipart/form-data"
        style="display: flex; flex-direction: column; gap: 12px;">
        <?php echo csrf_field(); ?>

        <div style="display: flex; flex-direction: column; gap: 4px;">
            <label>Título:</label>
            <input type="text" name="titulo" value="<?php echo e(old('titulo')); ?>" style="padding: 6px;">
        </div>

        <div style="display: flex; flex-direction: column; gap: 4px;">
            <label>Descripción:</label>
            <textarea name="descripcion" style="padding: 6px;"><?php echo e(old('descripcion')); ?></textarea>
        </div>

        <div style="display: flex; flex-direction: column; gap: 4px;">
            <label>URL del chollo:</label>
            <input type="text" name="url" value="<?php echo e(old('url')); ?>" style="padding: 6px;">
        </div>

        <div style="display: flex; flex-direction: column; gap: 4px;">
            <label>Categoría:</label>
            <select name="categoria_id" style="padding: 6px;">
                <option value="">-- Selecciona una categoría --</option>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($categoria->id); ?>"
                        <?php echo e(old('categoria_id') == $categoria->id ? 'selected' : ''); ?>>
                        <?php echo e($categoria->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div style="display: flex; flex-direction: column; gap: 4px;">
            <label>Puntuación (0-10):</label>
            <input type="number" name="puntuacion" min="0" max="10" value="<?php echo e(old('puntuacion')); ?>"
                style="padding: 6px;">
        </div>

        <div style="display: flex; flex-direction: column; gap: 4px;">
            <label>Precio original:</label>
            <input type="number" step="0.01" name="precio" value="<?php echo e(old('precio')); ?>" style="padding: 6px;">
        </div>

        <div style="display: flex; flex-direction: column; gap: 4px;">
            <label>Precio con descuento:</label>
            <input type="number" step="0.01" name="precio_descuento" value="<?php echo e(old('precio_descuento')); ?>"
                style="padding: 6px;">
        </div>

        <div style="display: flex; align-items: center; gap: 6px;">
            <label>Disponible:</label>
            <input type="checkbox" name="disponible" checked>
        </div>

        <div style="display: flex; flex-direction: column; gap: 4px;">
            <label>Imagen del chollo:</label>
            <input type="file" name="imagen">
        </div>

        <button type="submit" style="padding: 8px 14px; font-size: 16px; font-weight: bold; align-self: flex-end;">
            Crear chollo
        </button>

    </form>


    <p style="margin-top: 20px;">
        <a href="<?php echo e(route('chollos.index')); ?>">Volver al listado</a>
    </p>

    <footer style="text-align: right; margin-top: 40px; padding: 10px; color: #555;">
        © <?php echo e(date('Y')); ?> Fernando – Chollos App
    </footer>

</div>
<?php /**PATH C:\Users\DWES\chollos\resources\views/crear.blade.php ENDPATH**/ ?>