


<div style="max-width: 1000px; margin: 0 auto;">

    
    <header style="display: flex; align-items: center; gap: 20px; margin-bottom: 20px;">
        <img src="<?php echo e(asset('logo.jpg')); ?>" alt="Logo Chollos" width="80">
        <h1 style="margin: 0;">Chollos</h1>

        <nav style="display: flex; gap: 15px; margin-left: auto;">
            <a href="<?php echo e(route('chollos.index')); ?>">Inicio</a>
            <a href="<?php echo e(route('chollos.index', ['orden' => 'nuevos'])); ?>">Nuevos</a>
            <a href="<?php echo e(route('chollos.index', ['orden' => 'destacados'])); ?>">Destacados</a>
        </nav>
    </header>

    
    <div style="display: flex; align-items: center; margin-bottom: 20px;">

        <form action="<?php echo e(route('chollos.index')); ?>" method="GET" style="flex-grow: 1; margin-right: 20px;">
            <input type="hidden" name="categoria" value="<?php echo e(request('categoria')); ?>">
            <input type="text" name="buscar" placeholder="Buscar chollos..." value="<?php echo e(request('buscar')); ?>"
                style="width: 100%; padding: 8px; font-size: 16px;">
        </form>

        <div style="display: flex; align-items: center; gap: 15px;">

            <form action="<?php echo e(route('chollos.index')); ?>" method="GET"
                style="display: flex; align-items: center; gap: 10px;">
                <select name="categoria" style="height: 36px; padding: 5px; font-size: 16px;"
                    onchange="this.form.submit()">
                    <option value="">-- Categorías --</option>

                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($categoria->id); ?>"
                            <?php echo e(request('categoria') == $categoria->id ? 'selected' : ''); ?>>
                            <?php echo e($categoria->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" style="display:none;"></button>
            </form>

            <form action="<?php echo e(route('chollos.create')); ?>" method="GET">
                <button type="submit" style="font-size: 16px; height: 36px;">
                    Crear nuevo chollo
                </button>
            </form>

        </div>

    </div>

    
    <?php if(session('success')): ?>
        <p style="color: green;"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <p style="color: red;"><?php echo e(session('error')); ?></p>
    <?php endif; ?>

    
    <div style="display: flex; flex-wrap: wrap; gap: 20px; justify-content: space-between;">
        <?php $__currentLoopData = $chollos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chollo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="border: 1px solid #000; padding: 10px; width: 48%; box-sizing: border-box;">

                <h2><?php echo e($chollo->titulo); ?></h2>

                <?php if($chollo->imagen): ?>
                    <img src="<?php echo e(asset('storage/' . $chollo->imagen)); ?>" style="max-width: 120px; height: auto;">
                <?php endif; ?>

                <p><strong>Categoría:</strong> <?php echo e($chollo->categoria->name); ?></p>
                <p><strong>Puntuación:</strong> <?php echo e($chollo->puntuacion); ?></p>
                <p><strong>Precio:</strong> <?php echo e($chollo->precio); ?> €</p>
                <p><strong>Precio descuento:</strong> <?php echo e($chollo->precio_descuento); ?> €</p>

                <p><a href="<?php echo e(route('chollos.show', $chollo->id)); ?>">Ver detalle</a></p>
                <p><a href="<?php echo e(route('chollos.edit', $chollo->id)); ?>">Editar</a></p>

                <form action="<?php echo e(route('chollos.destroy', $chollo->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Borrar</button>
                </form>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php echo e($chollos->links('vendor.pagination.simple-default')); ?>


    <div style= "color: #555;text-align: right;">
        © <?php echo e(date('Y')); ?> Fernando – Chollos App
    </div>
</div>
<?php /**PATH C:\Users\DWES\chollos\resources\views/index.blade.php ENDPATH**/ ?>