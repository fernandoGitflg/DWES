
<header>
    <img src="<?php echo e(asset('logo.jpg')); ?>" alt="Logo Chollos" width="80">
    <h1>Chollos</h1>
    <nav>
        <a href="<?php echo e(route('chollos.index')); ?>">Inicio</a> |
        <a href="<?php echo e(route('chollos.index', ['orden' => 'nuevos'])); ?>">Nuevos</a> |
        <a href="<?php echo e(route('chollos.index', ['orden' => 'destacados'])); ?>">Destacados</a>
    </nav>
</header>

<h1>Gestión de Categorías</h1>


<?php if(session('success')): ?>
    <p style="color: green;"><?php echo e(session('success')); ?></p>
<?php endif; ?>

<?php if(session('error')): ?>
    <p style="color: red;"><?php echo e(session('error')); ?></p>
<?php endif; ?>


<?php if($errors->any()): ?>
    <div style="color: red;">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<h2>Crear nueva categoría</h2>

<form action="<?php echo e(route('categorias.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <p>
        <label>Nombre de la categoría:</label><br>
        <input type="text" name="name" value="<?php echo e(old('name')); ?>">
    </p>

    <p>
        <button type="submit">Crear categoría</button>
    </p>
</form>

<hr>


<h2>Listado de categorías</h2>

<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div style="border: 1px solid #000; padding: 10px; margin-bottom: 10px;">

        <p><strong>Nombre:</strong> <?php echo e($categoria->name); ?></p>
        <p><strong>Chollos asociados:</strong> <?php echo e($categoria->chollos_count); ?></p>

        
        <form action="<?php echo e(route('categorias.destroy', $categoria->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit">Eliminar</button>
        </form>

    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<p>
    <a href="<?php echo e(route('chollos.index')); ?>">Volver al listado de chollos</a>
</p>

<?php /**PATH C:\Users\DWES\chollos\resources\views/categorias.blade.php ENDPATH**/ ?>