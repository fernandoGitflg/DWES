
<header style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">

    <div style="display: flex; align-items: center; gap: 20px;">
        <img src="<?php echo e(asset('logo.jpg')); ?>" alt="Logo Chollos" width="80">

        <nav style="display: flex; gap: 15px;">
            <a href="<?php echo e(route('chollos.index')); ?>">Inicio</a>
            <a href="<?php echo e(route('chollos.index', ['orden' => 'nuevos'])); ?>">Nuevos</a>
            <a href="<?php echo e(route('chollos.index', ['orden' => 'destacados'])); ?>">Destacados</a>
        </nav>
    </div>

</header>

<h1>Detalle del Chollo</h1>


<?php if(session('success')): ?>
    <p style="color: green;"><?php echo e(session('success')); ?></p>
<?php endif; ?>

<?php if(session('error')): ?>
    <p style="color: red;"><?php echo e(session('error')); ?></p>
<?php endif; ?>


<h2><?php echo e($chollo->titulo); ?></h2>


<?php if($chollo->imagen): ?>
    <img src="<?php echo e(asset('storage/' . $chollo->imagen)); ?>" width="200">
<?php endif; ?>

<p><strong>Categoría:</strong> <?php echo e($chollo->categoria->name); ?></p>

<p><strong>Descripción:</strong></p>
<p><?php echo e($chollo->descripcion); ?></p>

<p><strong>Puntuación:</strong> <?php echo e($chollo->puntuacion); ?></p>

<p><strong>Precio original:</strong> <?php echo e($chollo->precio); ?> €</p>

<p><strong>Precio con descuento:</strong> <?php echo e($chollo->precio_descuento); ?> €</p>

<p>
    <strong>Enlace al chollo:</strong>
    <a href="<?php echo e($chollo->url); ?>" target="_blank">Visitar oferta</a>
</p>


<p>
    <a href="<?php echo e(route('chollos.index')); ?>">Volver al listado</a>
</p>
<footer style="text-align: right; margin-top: 40px; padding: 10px; color: #555;">
    © <?php echo e(date('Y')); ?> Fernando – Chollos App
</footer><?php /**PATH C:\Users\DWES\chollos\resources\views/detalle.blade.php ENDPATH**/ ?>