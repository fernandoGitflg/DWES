<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('chollos', function (Blueprint $table) {
            $table->id();
            $table->string('titulo');
            $table->text('descripcion');
            $table->string('url');
            $table->foreignId('categoria_id')->constrained('categorias')->cascadeOnDelete();
            $table->integer('puntuacion');
            $table->decimal('precio', 8, 2);
            $table->decimal('precio_descuento', 8, 2);
            $table->boolean('disponible')->default(true);
            $table->string('imagen')->nullable(); // para subir imagen
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('chollos');
    }
};

